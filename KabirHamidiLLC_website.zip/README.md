# KabirHamidi LLC Website

This is a static HTML/CSS website.

## Publish for free
Recommended: GitHub Pages.

1. Create a GitHub account.
2. Create a new public repository, e.g. `kabirhamidi-site`.
3. Upload `index.html`.
4. Open Settings → Pages.
5. Select Deploy from branch → main → /root.
6. GitHub will provide a free `github.io` address.

Your custom domain can be connected later if you own the domain and its DNS settings are available.
